package com.example.cryptage;

import android.content.Intent;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class formceasar extends AppCompatActivity {

    private Button retour, crypte, decrypte;
    static EditText texteclaire, textecrypte, cle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formceasar);

        texteclaire = (EditText) findViewById(R.id.clairceasar) ;
        textecrypte = (EditText) findViewById(R.id.crypteceasar);
        cle = (EditText) findViewById(R.id.cleceasar) ;

        crypte = (Button) findViewById(R.id.bcrypteceasar);
        crypte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cipherEncryption();
            }
        });

        decrypte = (Button) findViewById(R.id.bdecrypteceasar);
        decrypte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cipherDecryption();
            }
        });

        retour = (Button) findViewById(R.id.bretourceasar);
        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityretourceasar();
            }
        });


    }

    private void cipherDecryption() {
        String encypText = textecrypte.getText().toString();
        String dcyptkey = cle.getText().toString();
        String decrypMsg = "";

        for (int i = 0; i < encypText.length(); i++) {
            // now type casting
            if((int)encypText.charAt(i) == 32){
                decrypMsg += (char)32;
            } else if (((int)encypText.charAt(i) - Integer.parseInt(dcyptkey)) < 97 && ((int)encypText.charAt(i) - Integer.parseInt(dcyptkey)) > 90) {
                //lower case
                int temp = ((int)encypText.charAt(i) - Integer.parseInt(dcyptkey)) + 26;
                decrypMsg += (char)temp;
            } else if ((encypText.charAt(i) - Integer.parseInt(dcyptkey)) < 65) {
                // upper case
                int temp = ((int)encypText.charAt(i) - Integer.parseInt(dcyptkey)) + 26;
                decrypMsg += (char)temp;
            } else {
                decrypMsg += (char)((int)encypText.charAt(i) - Integer.parseInt(dcyptkey));
            }

        } // for loop

        texteclaire.setText(decrypMsg);
    }

    private void cipherEncryption() {
        String msg = texteclaire.getText().toString();
        String key = cle.getText().toString();
        String encrypMsg = "";

        for (int i = 0; i < msg.length(); i++) {
            // again casting
            if ((int)msg.charAt(i) == 32){
                encrypMsg += (char)32; // ignoring space, casting int to char

            } else if ((int)msg.charAt(i) + Integer.parseInt(key) > 122){
                int temp = ((int)msg.charAt(i) + Integer.parseInt(key) - 122);
                encrypMsg += (char)(96 + temp);

            } else if ((int)msg.charAt(i) + Integer.parseInt(key) > 90 && (int)msg.charAt(i) < 96){
                int temp = ((int)msg.charAt(i) + Integer.parseInt(key)) - 90;
                encrypMsg += (char)(64+temp);

            } else {
                encrypMsg += (char)((int)msg.charAt(i) + Integer.parseInt(key));

            }
        } // for loop

        textecrypte.setText(encrypMsg);
    }

    public void openActivityretourceasar() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }



}
