package com.example.cryptage;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class formatbash extends AppCompatActivity {

    private Button retour, crypte, decrypte;
    static EditText texteclaire, textecrypte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formatbash);
        texteclaire = (EditText) findViewById(R.id.claireatbash) ;
        textecrypte = (EditText) findViewById(R.id.crypteatbash);

        crypte = (Button) findViewById(R.id.bcrypteatbash);
        crypte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cipherEncryption();
            }
        });

        decrypte = (Button) findViewById(R.id.bdecrypteatbash);
        decrypte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cipherDecryption();
            }
        });

        retour = (Button) findViewById(R.id.bretouratbash);
        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityretour();
            }
        });
    }

    public void openActivityretour() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private static void cipherEncryption() {
        String alpa = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String reverseAlpa = "";
        // reversing alphabets
        for (int i = alpa.length()-1; i > -1; i--) {
            reverseAlpa += alpa.charAt(i);
        }


        String message = texteclaire.getText().toString();


        message = message.toUpperCase();

        String encryText = "";
        for (int i = 0; i < message.length(); i++) {
            if(message.charAt(i) == (char)32){
                encryText += " ";
            } else {
                int count = 0;
                for (int j = 0; j < alpa.length(); j++) {
                    if (message.charAt(i) == alpa.charAt(j)){
                        encryText += reverseAlpa.charAt(j);
                        break;
                    }
                } // inner for
            } // if-else
        } // for
        textecrypte.setText(encryText);
    }

    private static void cipherDecryption() {
        String alpa = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        String reverseAlpa = "";
        // reversing alphabets
        for (int i = alpa.length()-1; i > -1; i--) {
            reverseAlpa += alpa.charAt(i);
        }

        String message = textecrypte.getText().toString();

        String dencryText = "";
        for (int i = 0; i < message.length(); i++) {
            if(message.charAt(i) == (char)32){
                dencryText += " ";
            } else {
                int count = 0;
                for (int j = 0; j < reverseAlpa.length(); j++) {
                    if (message.charAt(i) == reverseAlpa.charAt(j)){
                        dencryText += alpa.charAt(j);
                        break;
                    }
                } // inner for
            } // if-else
        } // for

        texteclaire.setText(dencryText);
    }

}
