package com.example.cryptage;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import com.sun.mail.util.BASE64DecoderStream;
import com.sun.mail.util.BASE64EncoderStream;

public class formdes extends AppCompatActivity {

    private Button retour, crypte, decrypte;
    static EditText texteclaire, textecrypte;
    private static Cipher ecipher;
    private static Cipher dcipher;

    private static SecretKey key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formdes);

        texteclaire = (EditText) findViewById(R.id.clairedes) ;
        textecrypte = (EditText) findViewById(R.id.cryptedes);

        crypte = (Button) findViewById(R.id.bcryptedes);
        crypte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    key = KeyGenerator.getInstance("DES").generateKey();
                    ecipher = Cipher.getInstance("DES");
                    ecipher.init(Cipher.ENCRYPT_MODE, key);
                } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
                    e.printStackTrace();
                }
                String a;
                String str1 = texteclaire.getText().toString();
                a = cipherEncryption(str1);
                textecrypte.setText(a);
            }
        });

        decrypte = (Button) findViewById(R.id.bdecryptedes);
        decrypte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    key = KeyGenerator.getInstance("DES").generateKey();
                    dcipher = Cipher.getInstance("DES");
                    dcipher.init(Cipher.DECRYPT_MODE, key);
                } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
                    e.printStackTrace();
                }
                String b;
                String str2 = textecrypte.getText().toString();
                b = cipherDecryption(str2);
                texteclaire.setText(b);

            }
        });

        retour = (Button) findViewById(R.id.bretourdes);
        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityretour();
            }
        });
    }

    private void openActivityretour() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    private String cipherDecryption(String str) {
        try {

            // decode with base64 to get bytes

            byte[] dec = BASE64DecoderStream.decode(str.getBytes());

            byte[] utf8 = dcipher.doFinal(dec);

// create new string based on the specified charset

            return new String(utf8, "UTF8");

        }

        catch (Exception e) {

            e.printStackTrace();

        }

        return null;

    }


    private String cipherEncryption(String str) {
        try {



            byte[] utf8 = str.getBytes("UTF8");

            byte[] enc = ecipher.doFinal(utf8);

// encode to base64

            enc = BASE64EncoderStream.encode(enc);

            return new String(enc);

        }

        catch (Exception e) {

            e.printStackTrace();

        }

        return null;
    }
}
