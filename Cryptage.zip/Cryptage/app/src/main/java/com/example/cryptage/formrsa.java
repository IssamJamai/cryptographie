package com.example.cryptage;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class formrsa extends AppCompatActivity {

    private Button retour, crypte, decrypte;
    static EditText texteclaire, textecrypte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formrsa);

        texteclaire = (EditText) findViewById(R.id.clairersa) ;
        textecrypte = (EditText) findViewById(R.id.cryptersa);

        crypte = (Button) findViewById(R.id.bcryptersa);
        crypte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cipherEncryption();
            }
        });

        decrypte = (Button) findViewById(R.id.bdecryptersa);
        decrypte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cipherDecryption();
            }
        });

        retour = (Button) findViewById(R.id.bretourrsa);
        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityretour();
            }
        });
    }

    private void cipherDecryption() {
    }

    private void cipherEncryption() {
    }

    public void openActivityretour() {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}
