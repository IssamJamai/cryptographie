package com.example.cryptage;

import android.content.Intent;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private Button ceasar;
    private Button atbash;
    private Button hill;
    private Button vigenere;
    private Button des;
    private Button rsa;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ceasar = (Button) findViewById(R.id.bceasar);
        ceasar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityceasar();
            }
        });

        atbash = (Button) findViewById(R.id.batbash);
        atbash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityatbash();
            }
        });

        vigenere = (Button) findViewById(R.id.bvigenere);
        vigenere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityvigenere();
            }
        });

        hill = (Button) findViewById(R.id.bhill);
        hill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityhill();
            }
        });

        des = (Button) findViewById(R.id.bdes);
        des.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivitydes();
            }
        });

        rsa = (Button) findViewById(R.id.brsa);
        rsa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openActivityrsa();
            }
        });
    }
    public void openActivityceasar() {
    Intent intent = new Intent(this, formceasar.class);
    startActivity(intent);
    }
    public void openActivityhill() {
        Intent intent = new Intent(this, formhill.class);
        startActivity(intent);
    }
    public void openActivityatbash() {
        Intent intent = new Intent(this, formatbash.class);
        startActivity(intent);
    }
    public void openActivityrsa() {
        Intent intent = new Intent(this, formrsa.class);
        startActivity(intent);
    }
    public void openActivitydes() {
        Intent intent = new Intent(this, formdes.class);
        startActivity(intent);
    }
    public void openActivityvigenere() {
        Intent intent = new Intent(this, formvigenere.class);
        startActivity(intent);
    }
}


